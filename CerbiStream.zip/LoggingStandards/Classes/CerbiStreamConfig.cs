﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CerbiStream.Configuration
{
    public class CerbiStreamConfig
    {
        public bool EnableDevMode { get; set; } = true;  // ✅ Default is TRUE to prevent unintended logging
        public bool EnableEncryption { get; set; } = true; // ✅ Default to encrypt all logs
    }
}
