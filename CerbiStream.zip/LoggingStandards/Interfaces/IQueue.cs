﻿using CerbiClientLogging.Interfaces.SendMessage;

namespace CerbiClientLogging.Interfaces
{
    public interface IQueue : ISendMessage
    {
    }
}